package contrat;

/**
 * Représente le niveau d'une classe.
 */
public enum Niveau {
    L3, M1, M2
}
