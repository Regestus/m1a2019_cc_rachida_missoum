package contrat;

/**
 * Représente la filière des classes.
 */
public enum Filiere {
    CLASSIQUE, APPRENTISSAGE
}
