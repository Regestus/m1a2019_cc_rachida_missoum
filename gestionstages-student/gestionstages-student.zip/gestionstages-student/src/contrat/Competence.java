package contrat;

/**
 * Represente les competences recherchees dans les stages,
 * et ceux exprimees par les etudiants.
 */
public enum Competence {

    AMOA, AMOE, DONNEES, MOBILE, SECURITE, SYSADMIN, WEB
}
