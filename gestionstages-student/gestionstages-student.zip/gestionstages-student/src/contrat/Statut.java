package contrat;

/**
 * Represente le statut d'un stage.
 */
public enum Statut {
    ABANDONNE, EN_COURS, NON_AFFECTE, RETIRE, VALIDE
}
